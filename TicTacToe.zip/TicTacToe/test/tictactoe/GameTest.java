/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe;

import java.util.InputMismatchException;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Ignore;

/**
 *
 * @author Dell
 */
public class GameTest {

    private static String[] board;
    private static Game instance;

    public GameTest() {
    }

    @BeforeClass
    public static void setUpClass() {
        System.out.println("This test class is created to test the methods defined in the Game class.");
        System.out.println("");
        board = new String[9];
        instance = new Game();
    }

    @AfterClass
    public static void tearDownClass() {
        System.out.println("All tests have been run successfully!");
        
        System.out.println("-----------------------------------------------------------------------");
        System.out.println("-----------------------------------------------------------------------");
        System.out.println("");
    }

    @Before
    public void setUp() {
        instance.populateEmptyBoard(board);
    }

    @After
    public void tearDown() {
        System.out.println("----------------------------------------------------");
        System.out.println("");
    }

    @Test(expected = InputMismatchException.class)
    public void testCheckInputNegativeValue() {
        System.out.println("checkInput Test: checks that the entered value is not a negative one.");
        int userInput = -9;
        instance.checkInputNigativity(userInput);

    }

    @Test
    public void testCheckInputGreaterThanRange() {
        System.out.println("checkInput Test: checks that the entered value lies between 1 and 9, in this case the entered value is greater than the maximum allowed value.");
        int userInput = 10;
        boolean result = instance.checkInputRange(userInput);
        assertFalse(result);
    }

    @Test
    public void testCheckInputLessThanRange() {
        System.out.println("checkInput Test: checks that the entered value lies between 1 and 9, in this case the entered value is less than the minimum allowed value.");
        int userInput = 0;
        boolean result = instance.checkInputRange(userInput);
        assertFalse(result);
    }

    @Test
    public void testCheckInputInRange() {
        System.out.println("checkInput Test: checks that the entered value lies between 0 and 9, in this case the entered value is an acceptable one.");
        int userInput = 6;
        boolean result = instance.checkInputRange(userInput);
        assertTrue(result);
    }

    @Test
    public void testPlaceValueValidCell() {
        System.out.println("placeValue Test: checks that the required cell is not already taken, in this case the chosen cell is already occupied.");
        instance.populateEmptyBoard(board);
        instance.placeValue(1, board, "X");
        instance.placeValue(2, board, "O");
        int userInput = 3;
        String turn = "X";
        boolean result = instance.placeValue(userInput, board, turn);
        assertTrue(result);
    }

    @Test
    public void testPlaceValueInvalidCell() {
        System.out.println("placeValue Test: checks that the required cell is not already taken, in this case the chosen cell is available.");
        instance.populateEmptyBoard(board);
        instance.placeValue(1, board, "X");
        instance.placeValue(2, board, "O");
        int userInput = 2;
        String turn = "X";
        boolean result = instance.placeValue(userInput, board, turn);
        assertFalse(result);
    }

    @Test (timeout=200)
    public void testDetermineWhoseTurnX() /*throws InterruptedException*/ {
        System.out.println("determineWhoseTurn Test: ensures that the game is swapping between the players correctly. If the current turn is X, then the next turn should be O.");
        String currentTurn = "X";
        String expResult = "O";
        String result = instance.determineWhoseTurn(currentTurn);
        assertEquals(expResult, result);
//        while(true){
//            Thread.currentThread().sleep(1000);
//        }

    }

    @Test
    public void testDetermineWhoseTurnO() {
        System.out.println("determineWhoseTurn Test: ensures that the game is swapping between the players correctly. If the current turn is O, then the next turn should be X");
        String currentTurn = "O";
        String expResult = "X";
        String result = instance.determineWhoseTurn(currentTurn);
        assertEquals(expResult, result);

    }

    @Ignore("The method 'determineWhoseTurn' have already been tested!")
    @Test
    public void testDetermineWhoseTurnIncorrect() {
        System.out.println("determineWhoseTurn Test: ensures that the game is swapping between the players correctly.The resulted turn should not be the same as the current turn.");
        String currentTurn = "X";
        String expResult = "X";
        String result = instance.determineWhoseTurn(currentTurn);
        assertNotEquals(expResult, result);
    }

    @Test
    public void testGetPlayerOneName() {
        System.out.println("getPlayersNames Test: ensures that each player is assigned a name.");
        int num = 1;
        String expResult = "Player One";
        String result = instance.getPlayersNames(num);
        assertEquals(expResult, result);

    }

    @Test
    public void testGetPlayerTwoName() {
        System.out.println("getPlayersNames Test: ensures that each player is assigned a name.");
        int num = 2;
        String expResult = "Player Two";
        String result = instance.getPlayersNames(num);
        assertEquals(expResult, result);
    }

    @Test
    public void testCheckPlayerXTurn() {
        System.out.println("checkPlayerTurn: ensures that each player is assigned a value, either an X or O. The first player is always assigned the value X.");
        String value = "X";
        String playerOne = "Shoroog";
        String playerTwo = "Samar";
        String expResult = "Shoroog";
        String result = instance.checkPlayerTurn(value, playerOne, playerTwo);
        assertSame(expResult, result);
    }

    @Test
    public void testCheckPlayerOTurn() {
        System.out.println("checkPlayerTurn: ensures that each player is assigned a value, either an X or O. The second player is always assigned the value O.");
        String value = "O";
        String playerOne = "Shoroog";
        String playerTwo = "Samar";
        String expResult = "Samar";
        String result = instance.checkPlayerTurn(value, playerOne, playerTwo);
        assertSame(expResult, result);
    }

    @Test
    public void testPopulateEmptyBoardX() {
        System.out.println("populateEmptyBoard: ensures that the game resets the board everytime a player wins.");
        instance.populateEmptyBoard(board);
        instance.placeValue(1, board, "X");
        instance.placeValue(2, board, "O");
        instance.placeValue(4, board, "X");
        instance.placeValue(5, board, "O");
        instance.placeValue(7, board, "X");

        String[] resultedBoard = new String[board.length];
        for (int i = 0; i < resultedBoard.length; i++) {
            resultedBoard[i] = board[i];
        }
        String winner = instance.checkWinner(board);
        if (winner != null) {

            instance.populateEmptyBoard(board);

            assertNotSame(board, resultedBoard);
        }
    }

    @Test
    public void testPopulateEmptyBoardO() {
        System.out.println("populateEmptyBoard: ensures that the game resets the board everytime a player wins.");
        instance.populateEmptyBoard(board);
        instance.placeValue(1, board, "X");
        instance.placeValue(2, board, "O");
        instance.placeValue(4, board, "X");
        instance.placeValue(5, board, "O");
        instance.placeValue(9, board, "X");
        instance.placeValue(8, board, "X");

        String[] resultedBoard = new String[board.length];
        for (int i = 0; i < resultedBoard.length; i++) {
            resultedBoard[i] = board[i];
        }
        String winner = instance.checkWinner(board);
        if (winner != null) {

            instance.populateEmptyBoard(board);

            assertNotSame(board, resultedBoard);
        }
    }

}
