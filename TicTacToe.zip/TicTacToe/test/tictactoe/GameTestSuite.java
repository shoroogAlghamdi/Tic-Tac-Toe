
package tictactoe;
import org.junit.runners.Suite;
import org.junit.runner.RunWith;
@RunWith(Suite.class)


@Suite.SuiteClasses({GameTest.class, GameParameterizedTest.class})
public class GameTestSuite {
    
}
