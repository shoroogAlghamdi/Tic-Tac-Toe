/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe;

import java.util.Arrays;
import java.util.Collection;
import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class GameParameterizedTest {

    private static String[] board;
    private static Game instance;

    String expectedResult;

    public GameParameterizedTest(String[] board, String expectedResult) {
        super();
        this.board = board;
        this.expectedResult = expectedResult;
    }

    @BeforeClass
    public static void setUp(){
        System.out.println("This class a Parameterized test to execute the same test multiple times using different values. ");
        System.out.println("");
    }
    
    @Before
    public void initialize() {
        instance = new Game();
    }
    
    @After
    public void tearDown() {
        System.out.println("----------------------------------------------------");
        System.out.println("");
    }

    @AfterClass
    public static void tearDownClass() {
        System.out.println("All tests have been run successfully!");
        
        System.out.println("-----------------------------------------------------------------------");
        System.out.println("-----------------------------------------------------------------------");
        System.out.println("");
    }
    
    // Test of checkWinner method, of class Game.
     
    // Parameterized test
    @Parameters
    public static Collection input() {
        return Arrays.asList(new Object[][]{
            {new String[]{"X", "O", "3", "X", "O", "6", "7", "O", "X"}, "O"},
            {new String[]{"X", "O", "3", "X", "O", "6", "X", "8", "9"}, "X"},
            {new String[]{"X", "X", "X", "O", "O", "6", "7", "8", "9"}, "X"},
            {new String[]{"X", "X", "3", "O", "O", "O", "7", "8", "X"}, "O"}

        });
    }

    @Test (timeout=500)
    public void testGame() {
        System.out.println("The winer is: " + expectedResult);
        assertEquals(expectedResult, instance.checkWinner(board));
    }
}
