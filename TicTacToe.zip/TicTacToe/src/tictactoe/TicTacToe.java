/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TicTacToe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);   
        Game game = new Game();
        System.out.println("Welcome to 2 Player Tic Tac Toe.");
        System.out.println("--------------------------------");
        System.out.println("Enter First Player's Name");
        String playerOne = in.nextLine();
        if (playerOne.equals(" ")) {
            playerOne = game.getPlayersNames(1);
        }
        System.out.println("Enter Second Player's Name");
        String playerTwo = in.nextLine();

        
        
        if (playerTwo.equals(" ")) {
            playerTwo = game.getPlayersNames(2);
        }

        int count = 0;
        int playerOneScore = 0;
        int playerTwoScore = 0;

        boolean checkedRange, checkedPlacement;
        String turn, winner, playerTurn;
        String[] board = new String[9];

        while (count < 3) {
            turn = "X";
            winner = null;
            int numInput;
            game.populateEmptyBoard(board);
            game.printBoard(board);

            playerTurn = game.checkPlayerTurn(turn, playerOne, playerTwo);
            System.out.println(playerTurn + " will play first. Enter a slot number to place X in:");

            while (winner == null) {
                Game.winnerPlayer1 = false;
                Game.winnerPlayer2 = false;

                numInput = in.nextInt();

                checkedRange = game.checkInputRange(numInput);
                try {
                    Exception e = game.checkInputNigativity(numInput);
                } catch (InputMismatchException e) {

                    System.out.println("Invalid input (ONLY positive vlues are allowed). Re-enter slot number:");
                    continue;
                }

                if (!checkedRange) {
                    System.out.println("Invalid input (ONLY 1 to 9 values are allowed). Re-enter slot number:");
                    continue;
                }

                checkedPlacement = game.placeValue(numInput, board, turn);
                if (!checkedPlacement) {
                    System.out.println("Slot already taken; re-enter slot number:");
                    continue;
                }

                turn = game.determineWhoseTurn(turn);
                game.printBoard(board);

                winner = game.checkWinner(board);
                if (winner == null) {
                    playerTurn = game.checkPlayerTurn(turn, playerOne, playerTwo);
                    System.out.println(playerTurn + "'s turn; enter a slot number to place " + turn + " in:");
                }
            }

            if (winner.equalsIgnoreCase("draw")) {
                System.out.println("It's a draw for this round!");
            } else {
                playerTurn = game.checkPlayerTurn(winner, playerOne, playerTwo);

                if (Game.winnerPlayer1) {
                    playerOneScore++;

                }
                if (Game.winnerPlayer2) {
                    playerTwoScore++;
                }

                System.out.println("Congratulations! " + playerTurn + " have won this round!");
            }

            count++;
        }

        System.out.println(playerOne
                + "' score is " + playerOneScore + " " + playerTwo + "' score is " + playerTwoScore + ".");
        if (playerOneScore > playerTwoScore) {
            System.out.println("Congratulations! " + playerOne + " you won the game! Thanks for playing.");
        } else if (playerOneScore < playerTwoScore) {
            System.out.println("Congratulations! " + playerTwo + " you won the game! Thanks for playing.");
        } else {
            System.out.println("Oops! It is a draw! Thanks for playing.");
        }

    }

}
