/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe;

import java.util.Arrays;
import java.util.InputMismatchException;

public class Game {

    public static boolean winnerPlayer1 = false;
    public static boolean winnerPlayer2 = false;

    //--------------------------------------------------------------------------
    public String checkWinner(String[] board) {
        String winner = " ";
        for (int a = 0; a < 8; a++) {
            String line = null;
            switch (a) {
                case 0:
                    line = board[0] + board[1] + board[2];
                    break;
                case 1:
                    line = board[3] + board[4] + board[5];
                    break;
                case 2:
                    line = board[6] + board[7] + board[8];
                    break;
                case 3:
                    line = board[0] + board[3] + board[6];
                    break;
                case 4:
                    line = board[1] + board[4] + board[7];
                    break;
                case 5:
                    line = board[2] + board[5] + board[8];
                    break;
                case 6:
                    line = board[0] + board[4] + board[8];
                    break;
                case 7:
                    line = board[2] + board[4] + board[6];
                    break;
            }
            if (line.equals("XXX")) {
                winner = "X";
            } else if (line.equals("OOO")) {
                winner = "O";
            }
        }

        for (int a = 0; a < 9; a++) {
            if (Arrays.asList(board).contains(String.valueOf(a + 1))) {
                break;
            } else if (a == 8) {
                winner = "draw";
            }
        }

        return winner;
    }

    public void printBoard(String[] board) {
        System.out.println("/---|---|---\\");
        System.out.println("| " + board[0] + " | " + board[1] + " | " + board[2] + " |");
        System.out.println("|-----------|");
        System.out.println("| " + board[3] + " | " + board[4] + " | " + board[5] + " |");
        System.out.println("|-----------|");
        System.out.println("| " + board[6] + " | " + board[7] + " | " + board[8] + " |");
        System.out.println("/---|---|---\\");
    }

    public void populateEmptyBoard(String[] board) {
        for (int a = 0; a < 9; a++) {
            board[a] = String.valueOf(a + 1);
        }
    }

    public boolean checkInputRange(int userInput) {
        boolean correctness = true;
        if (!(userInput >= 1 && userInput <= 9)) {
            correctness = false;
        }
        return correctness;
    }

    public Exception checkInputNigativity(int userInput) {

        if (userInput < 0) {
            throw new InputMismatchException();
        }
        return null;
    }

    public boolean placeValue(int userInput, String[] originalBoard, String turn) {
        boolean correctness = true;
        if (originalBoard[userInput - 1].equals(String.valueOf(userInput))) {
            originalBoard[userInput - 1] = turn;
        } else {
            correctness = false;
        }
        return correctness;
    }

    public String determineWhoseTurn(String currentTurn) {
        if (currentTurn.equals("X")) {
            return "O";
        } else {
            return "X";
        }

    }

    public String getPlayersNames(int num) {
        if (num == 1) {
            return "Player One";
        } else {
            return "Player Two";

        }
    }

    public String checkPlayerTurn(String value, String playerOne, String playerTwo) {
        if (value.equalsIgnoreCase("X")) {
            winnerPlayer1 = true;
            return playerOne;
        } else {
            winnerPlayer2 = true;
            return playerTwo;
        }
    }

}
